const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('nexus', {
  getData: () => ipcRenderer.invoke('browser:data:get'),
  saveData: data => ipcRenderer.invoke('browser:data:save', data),
  windowControl: action => ipcRenderer.invoke('browser:window:control', action),
  openExternal: url => ipcRenderer.invoke('browser:shell:open', url),
  getAIUrl: () => ipcRenderer.invoke('browser:ai-url'),
  onDownload: callback => ipcRenderer.on('browser:download-updated', (_event, item) => callback(item)),
  onOpenUrl: callback => ipcRenderer.on('browser:open-url', (_event, url) => callback(url))
});
