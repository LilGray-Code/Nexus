const $ = id => document.getElementById(id);
const tabs = [];
let activeId = null;
let data = { bookmarks: [], history: [], downloads: [] };
let aiLocalUrl = '';
let browserInitialized = false;
const pendingExternalUrls = [];

const makeId = () => Math.random().toString(36).slice(2, 10);
const current = () => tabs.find(t => t.id === activeId);
const isHome = t => t && t.url === 'nexus://home';
const isAI = t => t && t.url === 'nexus://intelligence';

function normalize(input) {
  const value = String(input || '').trim();
  if (!value) return 'https://www.google.com';
  if (/^(https?:\/\/|file:\/\/)/i.test(value)) return value;
  if (/^[\w-]+\.[a-z]{2,}([/:?#]|$)/i.test(value) && !value.includes(' ')) return 'https://' + value;
  return 'https://www.google.com/search?q=' + encodeURIComponent(value);
}
function setStatus(value) { $('status').textContent = value; }

function createTab(url = 'nexus://home', options = {}) {
  const tab = {
    id: makeId(),
    url,
    title: options.private ? 'Ghost session' : (url === 'nexus://intelligence' ? 'Nexum Intelligence' : 'New journey'),
    private: !!options.private,
    view: null,
    secondView: null,
    loadUrl: options.ai ? aiLocalUrl : url,
    ai: !!options.ai
  };
  tabs.push(tab);
  activeId = tab.id;
  renderTabs();
  showTab(tab);
  return tab;
}

function renderTabs() {
  $('tabs').innerHTML = '';
  for (const tab of tabs) {
    const el = document.createElement('div');
    el.className = 'tab' + (tab.id === activeId ? ' active' : '');
    const name = document.createElement('button');
    name.className = 'tab-name';
    name.textContent = (tab.private ? '◌ ' : '') + (tab.ai ? '✳ ' : '') + tab.title;
    name.title = tab.title;
    name.onclick = () => { activeId = tab.id; renderTabs(); showTab(tab); };
    const close = document.createElement('button');
    close.className = 'tab-close';
    close.textContent = '×';
    close.title = 'Close tab';
    close.onclick = e => { e.stopPropagation(); closeTab(tab.id); };
    el.append(name, close);
    $('tabs').append(el);
  }
}

function makeWebview(tab, url) {
  const view = document.createElement('webview');
  view.setAttribute('src', url);
  view.setAttribute('allowpopups', '');
  view.setAttribute('partition', tab.private ? 'nexus-ghost-' + tab.id : (tab.ai ? 'persist:nexum-ai' : 'persist:nexus'));
  view.setAttribute('webpreferences', 'contextIsolation=yes, javascript=yes, webSecurity=yes');
  view.addEventListener('page-title-updated', e => {
    tab.title = e.title || tab.title;
    renderTabs();
  });
  view.addEventListener('did-navigate', e => {
    if (!tab.ai) tab.url = e.url;
    if (activeId === tab.id && !tab.ai) $('address').value = e.url;
    if (!tab.private && !tab.ai && !e.url.startsWith('file://')) recordHistory(tab, e.url);
  });
  view.addEventListener('did-navigate-in-page', e => {
    if (!tab.ai) tab.url = e.url;
    if (activeId === tab.id && !tab.ai) $('address').value = e.url;
  });
  view.addEventListener('did-start-loading', () => { if (activeId === tab.id) setStatus('CONNECTING / ' + (tab.ai ? 'NEXUM INTELLIGENCE' : 'REMOTE DESTINATION')); });
  view.addEventListener('did-stop-loading', () => { if (activeId === tab.id) setStatus(tab.ai ? 'NEXUM / LOCAL AI APP READY' : 'CONNECTED / DESTINATION LOADED'); });
  view.addEventListener('did-fail-load', e => {
    if (activeId === tab.id && e.errorCode !== -3) setStatus('LOAD ERROR / ' + e.errorDescription);
  });
  view.addEventListener('new-window', e => {
    if (e.url && /^https?:/i.test(e.url)) createTab(e.url);
  });
  return view;
}

function showTab(tab) {
  const web = $('webContainer');
  web.replaceChildren();
  web.classList.remove('split');
  $('sidePanel').classList.add('hidden');

  if (isHome(tab)) {
    $('homeView').style.display = 'flex';
    web.style.display = 'none';
    $('address').value = '';
    setStatus('READY / WAITING FOR DESTINATION');
    return;
  }

  $('homeView').style.display = 'none';
  web.style.display = 'flex';
  $('address').value = tab.ai ? 'nexus://intelligence · attached Nexum AI' : tab.url;

  if (!tab.view) tab.view = makeWebview(tab, tab.ai ? aiLocalUrl : tab.url);
  web.append(tab.view);
  if (tab.secondView) {
    web.append(tab.secondView);
    web.classList.add('split');
  }
}

function navigate(input) {
  const tab = current();
  if (!tab) return;
  const url = normalize(input);
  tab.ai = false;
  tab.url = url;
  tab.title = url.replace(/^https?:\/\//, '').split('/')[0] || 'New journey';
  tab.loadUrl = url;
  if (!tab.view) tab.view = makeWebview(tab, url);
  else tab.view.loadURL(url);
  if (tab.secondView) { tab.secondView.remove(); tab.secondView = null; }
  renderTabs();
  showTab(tab);
}
function openAI() {
  const existing = tabs.find(t => t.ai);
  if (existing) {
    activeId = existing.id;
    renderTabs();
    showTab(existing);
    return;
  }
  createTab('nexus://intelligence', { ai: true });
}
function closeTab(id) {
  const index = tabs.findIndex(t => t.id === id);
  if (index < 0) return;
  const tab = tabs[index];
  tab.view?.remove();
  tab.secondView?.remove();
  tabs.splice(index, 1);
  if (!tabs.length) createTab();
  else {
    activeId = tabs[Math.max(0, index - 1)].id;
    renderTabs();
    showTab(current());
  }
}
async function persist() {
  try { await window.nexus.saveData(data); }
  catch (error) { setStatus('SAVE ERROR / ' + error.message); }
}
function recordHistory(tab, url) {
  const entry = { title: tab.title, url, at: Date.now() };
  if (data.history[0]?.url !== url) {
    data.history.unshift(entry);
    data.history = data.history.slice(0, 500);
    persist();
  }
}
function panel(title, eyebrow, items, type) {
  $('panelTitle').textContent = title;
  $('panelEyebrow').textContent = eyebrow;
  const content = $('panelContent');
  content.replaceChildren();
  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'entry';
    empty.textContent = 'Nothing here yet. Your collection will appear here.';
    content.append(empty);
  }
  items.forEach((item, index) => {
    const el = document.createElement('div');
    el.className = 'entry';
    const label = document.createElement('span');
    label.textContent = item.title || item.name || 'Untitled';
    const small = document.createElement('small');
    small.textContent = item.url || item.path || new Date(item.at || item.startedAt || Date.now()).toLocaleString();
    el.append(label, small);
    if (type === 'bookmark' || type === 'history') {
      el.onclick = () => {
        const tab = current();
        if (tab) navigate(item.url);
        $('sidePanel').classList.add('hidden');
      };
    }
    if (type === 'bookmark') {
      const remove = document.createElement('button');
      remove.className = 'remove';
      remove.textContent = 'REMOVE';
      remove.onclick = e => {
        e.stopPropagation();
        data.bookmarks.splice(index, 1);
        persist();
        panel('Saved places', 'NEXUS / LIBRARY', data.bookmarks, 'bookmark');
      };
      el.append(remove);
    }
    content.append(el);
  });
  $('sidePanel').classList.remove('hidden');
}
function showPanel(which) {
  document.querySelectorAll('.dock-button[data-panel]').forEach(b => b.classList.toggle('selected', b.dataset.panel === which));
  if (which === 'home') {
    const tab = current();
    if (tab) {
      tab.ai = false;
      tab.url = 'nexus://home';
      tab.title = 'New journey';
      tab.view?.remove();
      tab.view = null;
      tab.secondView?.remove();
      tab.secondView = null;
      renderTabs();
      showTab(tab);
    }
  }
  if (which === 'bookmarks') panel('Saved places', 'NEXUS / LIBRARY', data.bookmarks, 'bookmark');
  if (which === 'history') panel('Your trail', 'NEXUS / TIMELINE', data.history, 'history');
  if (which === 'downloads') panel('Incoming files', 'NEXUS / TRANSFERS', data.downloads, 'download');
}

$('go').onclick = () => navigate($('address').value);
$('address').addEventListener('keydown', e => { if (e.key === 'Enter') navigate($('address').value); });
$('homeGo').onclick = () => navigate($('homeSearch').value);
$('homeSearch').addEventListener('keydown', e => { if (e.key === 'Enter') navigate($('homeSearch').value); });
$('newTab').onclick = () => createTab();
$('back').onclick = () => current()?.view?.goBack();
$('forward').onclick = () => current()?.view?.goForward();
$('reload').onclick = () => current()?.view?.reload();
$('bookmark').onclick = async () => {
  const tab = current();
  if (!tab || isHome(tab) || tab.ai || tab.url.startsWith('file://')) return;
  if (!data.bookmarks.some(item => item.url === tab.url)) {
    data.bookmarks.unshift({ title: tab.title, url: tab.url });
    await persist();
    setStatus('SAVED / BOOKMARK ADDED TO YOUR LIBRARY');
  } else setStatus('ALREADY SAVED / THIS PLACE IS IN YOUR LIBRARY');
};
$('split').onclick = () => {
  const tab = current();
  if (!tab || isHome(tab) || tab.ai) { setStatus('OPEN A WEBSITE BEFORE USING SPLIT VIEW'); return; }
  if (tab.secondView) {
    tab.secondView.remove();
    tab.secondView = null;
    showTab(tab);
    setStatus('SPLIT VIEW / CLOSED');
    return;
  }
  const second = window.prompt('Enter a second website or search: ', 'https://www.wikipedia.org');
  if (!second) return;
  tab.secondView = makeWebview(tab, normalize(second));
  showTab(tab);
  setStatus('SPLIT VIEW / TWO DESTINATIONS OPEN');
};
$('ghost').onclick = () => createTab('nexus://home', { private: true });
$('downloads').onclick = () => panel('Incoming files', 'NEXUS / TRANSFERS', data.downloads, 'download');
$('aiOpen').onclick = openAI;
$('panelClose').onclick = () => $('sidePanel').classList.add('hidden');

document.querySelectorAll('.dock-button[data-panel]').forEach(button => {
  button.onclick = () => showPanel(button.dataset.panel);
});
document.querySelectorAll('.shortcuts button').forEach(button => {
  button.onclick = () => navigate(button.dataset.url);
});
$('settingsBtn').onclick = () => {
  alert('NEXUS / SETTINGS\n\nCtrl+L — Focus address bar\nCtrl+T — New tab\nCtrl+W — Close tab\nCtrl+R — Reload\nCtrl+Shift+A — Open Nexum AI\n\nNexum AI runs from your attached ai.html file. Its local model setup and settings are managed inside that app.');
};
$('minBtn').onclick = () => window.nexus.windowControl('minimize');
$('maxBtn').onclick = () => window.nexus.windowControl('maximize');
$('closeBtn').onclick = () => window.nexus.windowControl('close');
window.nexus.onOpenUrl(url => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) return;
  if (!browserInitialized) pendingExternalUrls.push(url);
  else createTab(url);
});
window.nexus.onDownload(item => {
  const existing = data.downloads.find(x => x.name === item.name && x.startedAt === item.startedAt);
  if (existing) Object.assign(existing, item);
  else data.downloads.unshift(item);
  persist();
  setStatus('TRANSFER / ' + item.state.toUpperCase() + ' / ' + item.name);
});
document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key.toLowerCase() === 'l') { e.preventDefault(); $('address').focus(); $('address').select(); }
  if (e.ctrlKey && e.key.toLowerCase() === 't') { e.preventDefault(); createTab(); }
  if (e.ctrlKey && e.key.toLowerCase() === 'w') { e.preventDefault(); if (activeId) closeTab(activeId); }
  if (e.ctrlKey && e.key.toLowerCase() === 'r') { e.preventDefault(); current()?.view?.reload(); }
  if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a') { e.preventDefault(); openAI(); }
});
(async () => {
  try {
    [data, aiLocalUrl] = await Promise.all([window.nexus.getData(), window.nexus.getAIUrl()]);
    createTab();
    browserInitialized = true;
    while (pendingExternalUrls.length) createTab(pendingExternalUrls.shift());
  } catch (error) {
    setStatus('STARTUP ERROR / ' + (error?.message || 'Could not initialize Nexus Browser'));
  }
})();
