const { app, BrowserWindow, Menu, ipcMain, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

let desktopWindow = null;
let browserWindow = null;
let browserReady = false;
const pendingBrowserUrls = [];
const browserDataPath = () => path.join(app.getPath('userData'), 'nexus-browser-data.json');

function readBrowserData() {
  try {
    const data = JSON.parse(fs.readFileSync(browserDataPath(), 'utf8'));
    return {
      bookmarks: Array.isArray(data.bookmarks) ? data.bookmarks : [],
      history: Array.isArray(data.history) ? data.history : [],
      downloads: Array.isArray(data.downloads) ? data.downloads : []
    };
  } catch {
    return { bookmarks: [], history: [], downloads: [] };
  }
}

function writeBrowserData(data) {
  fs.mkdirSync(path.dirname(browserDataPath()), { recursive: true });
  fs.writeFileSync(browserDataPath(), JSON.stringify(data, null, 2), 'utf8');
}

function normalizeBrowserInput(input) {
  const value = String(input || '').trim();
  if (!value) return '';
  if (/^https?:\/\//i.test(value)) return value;
  if (/^[\w-]+\.[a-z]{2,}([/:?#]|$)/i.test(value) && !value.includes(' ')) return `https://${value}`;
  return `https://www.google.com/search?q=${encodeURIComponent(value)}`;
}

function sendBrowserUrl(url) {
  if (!url || !browserWindow || browserWindow.isDestroyed()) return;
  if (!browserReady) {
    pendingBrowserUrls.push(url);
    return;
  }
  browserWindow.webContents.send('browser:open-url', url);
}

function openBrowserWindow(input = '') {
  const url = normalizeBrowserInput(input);
  if (browserWindow && !browserWindow.isDestroyed()) {
    if (url) sendBrowserUrl(url);
    if (browserWindow.isMinimized()) browserWindow.restore();
    browserWindow.show();
    browserWindow.focus();
    return browserWindow;
  }

  browserReady = false;
  if (url) pendingBrowserUrls.push(url);
  browserWindow = new BrowserWindow({
    width: 1500,
    height: 960,
    minWidth: 980,
    minHeight: 650,
    backgroundColor: '#080d17',
    title: 'NEXUS — Nexus OS Browser',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'browser', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webviewTag: true
    }
  });

  browserWindow.webContents.on('will-attach-webview', (_event, webPreferences) => {
    delete webPreferences.preload;
    webPreferences.nodeIntegration = false;
    webPreferences.contextIsolation = true;
    webPreferences.sandbox = true;
  });

  browserWindow.webContents.on('did-attach-webview', (_event, webContents) => {
    attachDownloadTracking(webContents.session);
    webContents.setWindowOpenHandler(({ url: target }) => {
      if (/^https?:\/\//i.test(target)) sendBrowserUrl(target);
      return { action: 'deny' };
    });
  });

  browserWindow.webContents.setWindowOpenHandler(({ url: target }) => {
    if (/^https?:\/\//i.test(target)) sendBrowserUrl(target);
    return { action: 'deny' };
  });

  browserWindow.loadFile(path.join(__dirname, 'browser', 'index.html'));
  browserWindow.webContents.once('did-finish-load', () => {
    browserReady = true;
    while (pendingBrowserUrls.length) {
      browserWindow.webContents.send('browser:open-url', pendingBrowserUrls.shift());
    }
  });
  browserWindow.on('closed', () => {
    browserWindow = null;
    browserReady = false;
    pendingBrowserUrls.length = 0;
  });
  return browserWindow;
}

const trackedSessions = new WeakSet();
function attachDownloadTracking(browserSession) {
  if (!browserSession || trackedSessions.has(browserSession)) return;
  trackedSessions.add(browserSession);
  browserSession.on('will-download', (_event, item) => {
    const data = readBrowserData();
    const entry = {
      name: item.getFilename(),
      path: item.getSavePath(),
      startedAt: Date.now(),
      state: 'progress'
    };
    data.downloads.unshift(entry);
    data.downloads = data.downloads.slice(0, 300);
    writeBrowserData(data);

    item.on('updated', () => {
      entry.receivedBytes = item.getReceivedBytes();
      entry.totalBytes = item.getTotalBytes();
      writeBrowserData(readBrowserDataWithEntry(entry));
      if (browserWindow && !browserWindow.isDestroyed()) {
        browserWindow.webContents.send('browser:download-updated', entry);
      }
    });
    item.once('done', (_event, state) => {
      entry.state = state;
      entry.path = item.getSavePath();
      writeBrowserData(readBrowserDataWithEntry(entry));
      if (browserWindow && !browserWindow.isDestroyed()) {
        browserWindow.webContents.send('browser:download-updated', entry);
      }
    });
  });
}

function readBrowserDataWithEntry(entry) {
  const data = readBrowserData();
  const index = data.downloads.findIndex(item => item.name === entry.name && item.startedAt === entry.startedAt);
  if (index >= 0) data.downloads[index] = { ...data.downloads[index], ...entry };
  else data.downloads.unshift(entry);
  return data;
}

function createDesktopWindow() {
  desktopWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 800,
    minHeight: 560,
    title: 'Nexus OS',
    backgroundColor: '#101a30',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  desktopWindow.loadFile(path.join(__dirname, 'index.html'));
  desktopWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) openBrowserWindow(url);
    return { action: 'deny' };
  });
  desktopWindow.webContents.on('will-navigate', (event, url) => {
    if (/^https?:\/\//i.test(url)) {
      event.preventDefault();
      openBrowserWindow(url);
    }
  });
  desktopWindow.on('closed', () => { desktopWindow = null; });
}

function activateNexusInstance(commandLine = []) {
  const args = Array.isArray(commandLine) ? commandLine : [];
  const requestedUrl = args.find(value => typeof value === 'string' && /^https?:\/\//i.test(value)) || '';
  const browserRequested = args.includes('--browser') || Boolean(requestedUrl);

  if (browserRequested) {
    openBrowserWindow(requestedUrl);
    return;
  }

  if (desktopWindow && !desktopWindow.isDestroyed()) {
    if (desktopWindow.isMinimized()) desktopWindow.restore();
    desktopWindow.show();
    desktopWindow.focus();
  } else if (browserWindow && !browserWindow.isDestroyed()) {
    if (browserWindow.isMinimized()) browserWindow.restore();
    browserWindow.show();
    browserWindow.focus();
  } else {
    createDesktopWindow();
  }
}

// Reuse the running Nexus instance when the OS opens a web link or the user
// launches the browser from the application menu.
const hasSingleInstanceLock = app.requestSingleInstanceLock();
if (!hasSingleInstanceLock) {
  app.quit();
} else {
  app.on('second-instance', (_event, commandLine) => {
    if (app.isReady()) activateNexusInstance(commandLine);
    else app.whenReady().then(() => activateNexusInstance(commandLine));
  });

  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    attachDownloadTracking(session.fromPartition('persist:nexus'));
    activateNexusInstance(process.argv.slice(1));
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createDesktopWindow();
    });
  });
}

ipcMain.handle('os:open-browser', (_event, input) => {
  if (typeof input !== 'string' || input.length > 4096) throw new Error('Invalid browser destination.');
  openBrowserWindow(input);
  return true;
});

ipcMain.handle('browser:data:get', () => readBrowserData());
ipcMain.handle('browser:data:save', (_event, data) => {
  if (!data || typeof data !== 'object') throw new Error('Invalid browser data.');
  writeBrowserData({
    bookmarks: Array.isArray(data.bookmarks) ? data.bookmarks.slice(0, 1000) : [],
    history: Array.isArray(data.history) ? data.history.slice(0, 1000) : [],
    downloads: Array.isArray(data.downloads) ? data.downloads.slice(0, 300) : []
  });
  return true;
});
ipcMain.handle('browser:window:control', (event, action) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win || win.isDestroyed()) return;
  if (action === 'minimize') win.minimize();
  if (action === 'maximize') win.isMaximized() ? win.unmaximize() : win.maximize();
  if (action === 'close') win.close();
});
ipcMain.handle('browser:ai-url', () => pathToFileURL(path.join(__dirname, 'ai.html')).href);
ipcMain.handle('browser:shell:open', (_event, url) => {
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    throw new Error('Only HTTP and HTTPS links can be opened.');
  }
  openBrowserWindow(url);
  return true;
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
