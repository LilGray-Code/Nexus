const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('nexusOS', {
  openBrowser: input => ipcRenderer.invoke('os:open-browser', input || '')
});
