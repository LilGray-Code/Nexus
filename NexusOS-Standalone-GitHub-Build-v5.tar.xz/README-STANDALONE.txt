NEXUS OS — STANDALONE BOOTABLE PROJECT
======================================

This project packages the supplied Nexus OS Desktop 1.3.0 application into
a Debian 13 (Trixie) amd64 live/install system. The NexusDesktop folder
retains the original Electron shell, Nexus Browser and supplied ai.html.
The Linux package installs the app under /opt and exposes the nexus-os
launcher command.

BOOT TARGET
- 64-bit x86-64 / amd64
- Hybrid ISO intended for legacy x86-64 BIOS and UEFI boot
- Live desktop auto-login as the local live user "nexus"
- Calamares desktop installer launcher with live-session fstab/X11 preparation
  and restoration, plus Debian live-installer boot path
- Nexus Browser is the system HTTP/HTTPS handler and has its own direct launcher
- Debian Trixie Calamares settings/modules retained, with Nexus branding applied
- Lightweight panel, Thunar file manager, PipeWire audio and power-management tools

BUILD OPTIONS
A. Hosted GitHub Actions build (recommended if using GitHub):
   1. Read GITHUB-BUILD-INSTRUCTIONS.txt.
   2. Create the empty GitHub repository with a README as described there.
   3. Push this project to its main/master branch.
   4. Download the NexusOS-Standalone-amd64 artifact from the Actions run.

B. Local Debian 13 amd64 build:
   1. Use an internet-connected Debian 13 amd64 computer.
   2. Run ./build/prepare-build-host.sh
   3. Run ./build/build-iso.sh
   4. Verify with sha256sum -c release/SHA256SUMS.txt

IMPORTANT LIMITATIONS
- This ZIP is source/build material, not a prebuilt ISO. No ISO has been built
  or tested yet. Do not write this ZIP directly to a USB as an installer.
- Secure Boot is not signed/enabled; disable Secure Boot if needed to boot.
- Legacy BIOS support applies to x86-64 only; 32-bit PCs are not supported.
- Hardware support depends on Linux kernel and firmware availability.
- The desktop app is Electron-based and runs as the shell over Debian Linux;
  this project does not provide a new kernel or fully native OS stack.
- Browser webview operation and Nexum AI's WebGPU/model support depend on
  hardware and browser support. The first AI model load may download data.
- Calamares and Debian live-installer paths need validation before use on a
  computer containing important data. Back up first; erasing a selected disk
  destroys its data.
- The in-app File Explorer remains a sample UI; the desktop Files menu opens
  the functional Thunar file manager.
